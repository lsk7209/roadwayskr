/**
 * TourAPI 변경분 동기화 (incremental)
 *
 * 사용:
 *   pnpm sync:tourapi              # 어제 modified 분만 (cron용)
 *   pnpm sync:tourapi:full         # 전체 1년치 (최초 적재용)
 *
 * - 변경분 = areaBasedSyncList2 (modifiedtime 이후)
 * - 각 항목에 대해 detailCommon2 + detailIntro2 추가 호출 → 정규화 → upsert
 * - sync_runs 테이블에 이력 기록
 * - 일일 호출 한도(1만) 보호: 한 번 sync에 최대 2,500 항목까지
 */

import { eq } from "drizzle-orm";
import { db } from "../db";
import { festivals, syncRuns } from "../db/schema";
import {
  fetchSyncList,
  fetchFestivalDetail,
  fetchFestivals,
  normalizeFestival,
  TourApiError,
} from "../lib/tourapi";

const MODE = (process.argv.find((a) => a.startsWith("--mode="))?.split("=")[1] ??
  "incremental") as "incremental" | "full";

const MAX_ITEMS_PER_RUN = 2_500;
const RPS_DELAY_MS = 200; // 초당 ~5건. 일 한도 안전 영역.

async function main() {
  console.log(`[sync-tourapi] mode=${MODE} startAt=${new Date().toISOString()}`);

  const [run] = await db
    .insert(syncRuns)
    .values({ source: "tourapi", mode: MODE })
    .returning();

  let inserted = 0;
  let updated = 0;
  let skipped = 0;
  let errors = 0;
  const errorSamples: Array<{ contentId?: string; error: string }> = [];

  try {
    const items =
      MODE === "full" ? await collectFullYear() : await collectIncremental();

    console.log(`[sync-tourapi] candidates=${items.length}`);

    const limited = items.slice(0, MAX_ITEMS_PER_RUN);
    if (limited.length < items.length) {
      console.warn(
        `[sync-tourapi] truncated: ${items.length} → ${limited.length} (한도 보호)`,
      );
    }

    for (const base of limited) {
      try {
        const detail = await fetchFestivalDetail(base.contentid);
        await sleep(RPS_DELAY_MS);

        const normalized = normalizeFestival({
          base,
          common: detail.common,
          intro: detail.intro,
        });

        const result = await upsertFestival(normalized);
        if (result === "inserted") inserted++;
        else if (result === "updated") updated++;
        else skipped++;
      } catch (err) {
        errors++;
        errorSamples.push({
          contentId: base.contentid,
          error: err instanceof Error ? err.message : String(err),
        });
        if (err instanceof TourApiError && err.resultCode === "22") {
          console.error("[sync-tourapi] API 한도 초과 - 중단");
          break;
        }
      }
    }

    await db
      .update(syncRuns)
      .set({
        finishedAt: new Date(),
        insertedCount: inserted,
        updatedCount: updated,
        skippedCount: skipped,
        errorCount: errors,
        notes: `processed=${limited.length}/${items.length}`,
        errorJson:
          errorSamples.length > 0
            ? JSON.stringify(errorSamples.slice(0, 20))
            : null,
      })
      .where(eq(syncRuns.id, run.id));

    console.log(
      `[sync-tourapi] done. inserted=${inserted} updated=${updated} skipped=${skipped} errors=${errors}`,
    );
  } catch (fatal) {
    await db
      .update(syncRuns)
      .set({
        finishedAt: new Date(),
        insertedCount: inserted,
        updatedCount: updated,
        errorCount: errors + 1,
        notes: "FATAL",
        errorJson: JSON.stringify({
          error: fatal instanceof Error ? fatal.message : String(fatal),
        }),
      })
      .where(eq(syncRuns.id, run.id));
    console.error("[sync-tourapi] FATAL:", fatal);
    process.exitCode = 1;
  }
}

async function collectIncremental() {
  const yesterday = new Date();
  yesterday.setUTCDate(yesterday.getUTCDate() - 1);
  const ymd = yesterday.toISOString().slice(0, 10).replace(/-/g, "");

  const all: Awaited<ReturnType<typeof fetchSyncList>>["items"] = [];
  let pageNo = 1;
  while (true) {
    const { items, totalCount } = await fetchSyncList(ymd, pageNo);
    all.push(...items);
    await sleep(RPS_DELAY_MS);
    if (all.length >= totalCount || items.length === 0) break;
    pageNo++;
    if (pageNo > 100) break; // safety
  }
  return all as any[];
}

async function collectFullYear() {
  // 오늘 ~ 12개월 후 행사 (전체 시도)
  const today = new Date();
  const start = today.toISOString().slice(0, 10).replace(/-/g, "");
  const end = new Date(today.getTime() + 365 * 86_400_000)
    .toISOString()
    .slice(0, 10)
    .replace(/-/g, "");

  const all: any[] = [];
  let pageNo = 1;
  while (true) {
    const { items, totalCount } = await fetchFestivals({
      eventStartDate: start,
      eventEndDate: end,
      pageNo,
      numOfRows: 100,
    });
    all.push(...items);
    await sleep(RPS_DELAY_MS);
    if (all.length >= totalCount || items.length === 0) break;
    pageNo++;
    if (pageNo > 100) break;
  }
  return all;
}

async function upsertFestival(row: typeof festivals.$inferInsert) {
  const existing = await db
    .select({ id: festivals.contentId })
    .from(festivals)
    .where(eq(festivals.contentId, row.contentId))
    .limit(1);

  if (existing.length === 0) {
    await db.insert(festivals).values(row);
    return "inserted" as const;
  }

  await db
    .update(festivals)
    .set({
      ...row,
      updatedAt: new Date(),
    })
    .where(eq(festivals.contentId, row.contentId));
  return "updated" as const;
}

function sleep(ms: number) {
  return new Promise((r) => setTimeout(r, ms));
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
